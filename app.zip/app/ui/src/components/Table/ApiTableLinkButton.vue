<template>
	<Button
		v-slot="buttonProps"
		as-child
		rounded
		severity="secondary"
		text>
		<RouterLink
			class="api-table-link-button"
			:class="buttonProps.class"
			:to>
			<FontAwesomeIcon :icon />
		</RouterLink>
	</Button>
</template>

<script setup lang="ts">
import { RouterLink } from 'vue-router'
import Button from 'primevue/button'
import FontAwesomeIcon from '@/components/FontAwesomeIcon.vue'

defineProps<{
	to: InstanceType<typeof RouterLink>['$props']['to']
	icon: string
}>()
</script>

<style lang="scss" scoped>
.api-table-link-button {
	width: 30px;
	height: 30px;
	border-radius: 100%;
}
</style>
