<template>
	<Drawer
		v-model:visible="isActive"
		class="department-appointments-add-dialog"
		header="Add Appointments"
		position="right">
		<div class="department-appointments-add-dialog__header">
			<div class="department-appointments-add-dialog__assigned-filter-container">
				<div class="department-appointments-add-dialog__assigned-filter-label-container">
					<label>Show all Appointments</label>
					<label
						><small
							>Assigning Appointments to this Department will change their current assignment</small
						></label
					>
				</div>
				<ToggleSwitch v-model="withAssigned" />
			</div>
			<div class="department-appointments-add-dialog__search-container">
				<IconField>
					<InputIcon class="fal fa-search" />
					<InputText
						v-model="searchString"
						class="department-appointments-add-dialog__search-input"
						placeholder="Search"
						@keyup.enter="listState.getList({ search: searchString })"
						@update:model-value="listState.getList({ search: searchString })"></InputText>
				</IconField>
			</div>
		</div>
		<div class="department-appointments-add-dialog__table-container">
			<ApiTable
				v-model:selection="selected"
				flat
				selection-mode="multiple"
				:list-state="listState">
				<Column
					header-style="width: 3rem"
					selection-mode="multiple"></Column>
				<Column
					field="reason_for_visit"
					header="Reason For Visit" />
			</ApiTable>
		</div>
		<div class="department-appointments-add-dialog__add-buttton-container">
			<Button
				class="department-appointments-add-dialog__add-button"
				icon="fal fa-plus"
				:disabled="selected.length === 0"
				:label="`Add ${selected.length} Appointments`"
				:loading="isLoading"
				@click="submit" />
		</div>
	</Drawer>
</template>

<script setup lang="ts">
import Drawer from 'primevue/drawer'
import Button from 'primevue/button'
import InputText from 'primevue/inputtext'
import InputIcon from 'primevue/inputicon'
import IconField from 'primevue/iconfield'
import ToggleSwitch from 'primevue/toggleswitch'
import useApiTable from '@/components/Table/useApiTable'
import { ref, watch } from 'vue'
import { useAppointmentListState } from '@/models/Appointment/States'
import DepartmentsApi from '@/models/Department/Api'
import type { Department } from '@/models/Department/Model'
import type { Appointment } from '@/models/Appointment/Model'

const props = defineProps<{
	departmentId: Department['id']
}>()

const emit = defineEmits<{
	(e: 'update'): void
}>()

const listState = useAppointmentListState()
listState.defaultParams = {
	notFromRelation: {
		model: 'App\\Models\\Department',
		id: props.departmentId,
		relation: 'appointments',
	},
}
const { ApiTable, Column } = useApiTable(listState)

const isActive = defineModel<boolean>()
const selected = ref<Appointment[]>([])
const isLoading = ref(false)
const searchString = ref('')
const withAssigned = ref(false)

watch(
	withAssigned,
	() => {
		if (withAssigned.value) {
			listState.query().save()
		} else {
			listState.query().whereDoesntHave('department').save()
		}
		if (isActive.value) {
			listState.getList()
		}
	},
	{ immediate: true },
)

watch(
	isActive,
	() => {
		if (!isActive.value) {
			withAssigned.value = false
			searchString.value = ''
			selected.value = []
			listState.clearList()
		} else {
			listState.getList()
		}
	},
	{ immediate: true },
)

async function submit() {
	isLoading.value = true
	try {
		await new DepartmentsApi().updateRelation(props.departmentId, 'appointments', {
			method: 'associate',
			params: selected.value.map((item) => item.id),
		})
		isActive.value = false
		emit('update')
		selected.value = []
	} finally {
		isLoading.value = false
	}
}
</script>

<style lang="scss">
.department-appointments-add-dialog {
	width: 800px !important;

	.p-drawer-content {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 0;
	}

	.department-appointments-add-dialog__header {
		padding: 10px;
		display: flex;
		flex-direction: column;
		align-items: flex-end;
		justify-content: space-between;
		gap: 20px;

		.department-appointments-add-dialog__search-container {
			flex: 1;
			width: 100%;

			.department-appointments-add-dialog__search-input {
				width: 100%;
			}
		}

		.department-appointments-add-dialog__assigned-filter-container {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 10px;

			.department-appointments-add-dialog__assigned-filter-label-container {
				display: flex;
				flex-direction: column;

				& > label {
					line-height: 1.2;
					text-align: right;

					small {
						opacity: 0.5;
					}
				}
			}
		}
	}

	.department-appointments-add-dialog__table-container {
		border-top: 1px solid var(--p-datatable-body-cell-border-color);
		flex: 1;
		overflow: auto;
		display: flex;

		.ui-api-table__table {
			flex: 1;
		}
	}

	.department-appointments-add-dialog__add-buttton-container {
		padding: 20px;
		display: flex;
		justify-content: flex-end;
		border-top: 1px solid var(--p-datatable-body-cell-border-color);

		.department-appointments-add-dialog__add-button {
			min-height: 39px;
		}
	}
}
</style>
