<template>
	<Drawer
		v-model:visible="isActive"
		class="medication-treatments-add-dialog"
		header="Add Treatments"
		position="right">
		<div class="medication-treatments-add-dialog__header">
			<div class="medication-treatments-add-dialog__assigned-filter-container">
				<div class="medication-treatments-add-dialog__assigned-filter-label-container">
					<label>Show all Treatments</label>
					<label
						><small
							>Assigning Treatments to this Medication will add to their current assignments</small
						></label
					>
				</div>
				<ToggleSwitch v-model="withAssigned" />
			</div>
			<div class="medication-treatments-add-dialog__search-container">
				<IconField>
					<InputIcon class="fal fa-search" />
					<InputText
						v-model="searchString"
						class="medication-treatments-add-dialog__search-input"
						placeholder="Search"
						@keyup.enter="listState.getList({ search: searchString })"
						@update:model-value="listState.getList({ search: searchString })"></InputText>
				</IconField>
			</div>
		</div>
		<div class="medication-treatments-add-dialog__table-container">
			<ApiTable
				v-model:selection="selected"
				flat
				selection-mode="multiple"
				:list-state="listState">
				<Column
					header-style="width: 3rem"
					selection-mode="multiple"></Column>
				<Column
					field="description"
					header="Description" />
			</ApiTable>
		</div>
		<div class="medication-treatments-add-dialog__add-buttton-container">
			<Button
				class="medication-treatments-add-dialog__add-button"
				icon="fal fa-plus"
				:disabled="selected.length === 0"
				:label="`Add ${selected.length} Treatments`"
				:loading="isLoading"
				@click="submit" />
		</div>
	</Drawer>
</template>

<script setup lang="ts">
import Drawer from 'primevue/drawer'
import Button from 'primevue/button'
import InputText from 'primevue/inputtext'
import InputIcon from 'primevue/inputicon'
import IconField from 'primevue/iconfield'
import ToggleSwitch from 'primevue/toggleswitch'
import useApiTable from '@/components/Table/useApiTable'
import { ref, watch } from 'vue'
import { useTreatmentListState } from '@/models/Treatment/States'
import MedicationsApi from '@/models/Medication/Api'
import type { Medication } from '@/models/Medication/Model'
import type { Treatment } from '@/models/Treatment/Model'

const props = defineProps<{
	medicationId: Medication['id']
}>()

const emit = defineEmits<{
	(e: 'update'): void
}>()

const listState = useTreatmentListState()
listState.defaultParams = {
	notFromRelation: {
		model: 'App\\Models\\Medication',
		id: props.medicationId,
		relation: 'treatments',
	},
}
const { ApiTable, Column } = useApiTable(listState)

const isActive = defineModel<boolean>()
const selected = ref<Treatment[]>([])
const isLoading = ref(false)
const searchString = ref('')
const withAssigned = ref(true)

watch(
	withAssigned,
	() => {
		if (withAssigned.value) {
			listState.query().save()
		} else {
			listState.query().whereDoesntHave('medications').save()
		}
		if (isActive.value) {
			listState.getList()
		}
	},
	{ immediate: true },
)

watch(
	isActive,
	() => {
		if (!isActive.value) {
			withAssigned.value = true
			searchString.value = ''
			selected.value = []
			listState.clearList()
		} else {
			listState.getList()
		}
	},
	{ immediate: true },
)

async function submit() {
	isLoading.value = true
	try {
		await new MedicationsApi().updateRelation(props.medicationId, 'treatments', {
			method: 'syncWithoutDetaching',
			params: selected.value.map((item) => item.id),
		})
		isActive.value = false
		emit('update')
		selected.value = []
	} finally {
		isLoading.value = false
	}
}
</script>

<style lang="scss">
.medication-treatments-add-dialog {
	width: 800px !important;

	.p-drawer-content {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 0;
	}

	.medication-treatments-add-dialog__header {
		padding: 10px;
		display: flex;
		flex-direction: column;
		align-items: flex-end;
		justify-content: space-between;
		gap: 20px;

		.medication-treatments-add-dialog__search-container {
			flex: 1;
			width: 100%;

			.medication-treatments-add-dialog__search-input {
				width: 100%;
			}
		}

		.medication-treatments-add-dialog__assigned-filter-container {
			display: flex;
			align-items: center;
			justify-content: space-between;
			gap: 10px;

			.medication-treatments-add-dialog__assigned-filter-label-container {
				display: flex;
				flex-direction: column;

				& > label {
					line-height: 1.2;
					text-align: right;

					small {
						opacity: 0.5;
					}
				}
			}
		}
	}

	.medication-treatments-add-dialog__table-container {
		border-top: 1px solid var(--p-datatable-body-cell-border-color);
		flex: 1;
		overflow: auto;
		display: flex;

		.ui-api-table__table {
			flex: 1;
		}
	}

	.medication-treatments-add-dialog__add-buttton-container {
		padding: 20px;
		display: flex;
		justify-content: flex-end;
		border-top: 1px solid var(--p-datatable-body-cell-border-color);

		.medication-treatments-add-dialog__add-button {
			min-height: 39px;
		}
	}
}
</style>
