<template>
	<Card class="tags-relation-widget">
		<template #title>
			<h4 class="tags-relation-widget__title">Tags</h4>
			<Button
				icon="fal fa-link"
				label="Connect"
				outlined
				severity="secondary"
				@click="isRelationAddDialogActive = true" />
			<Button
				icon="fal fa-plus"
				label="Create"
				outlined
				severity="secondary"
				@click="isFormActive = true" />
		</template>
		<template #content>
			<ApiTable
				flat
				:list-state="listState">
				<Column
					field="name"
					header="Name" />
				<Column
					header=""
					:style="{ maxWidth: '92px', width: '92px' }">
					<template #body="{ data }">
						<ApiTableLinkButton
							icon="fal fa-arrow-up-right-from-square"
							:to="{ name: 'tags-edit', params: { id: data.id } }" />
						<Button
							class="tags-relation-widget__table-button"
							icon="fal fa-xmark"
							rounded
							severity="secondary"
							text
							:loading="detachLoading === data.id"
							@click.stop.prevent="detach(data)" />
					</template>
				</Column>
			</ApiTable>
		</template>
	</Card>
	<TagsRelationAddDialog
		v-model="isRelationAddDialogActive"
		:medication-id="props.medicationId"
		@update="refresh()" />
	<TagForm
		:as-dialog="true"
		:attach-to="{ medications: { method: 'syncWithoutDetaching', id: props.medicationId } }"
		:should-redirect="false"
		:visible="isFormActive"
		@close="isFormActive = false"
		@created="refresh()"
		@submit="isFormActive = false" />
</template>

<script setup lang="ts">
import Card from 'primevue/card'
import Button from 'primevue/button'
import useApiTable from '@/components/Table/useApiTable'
import { onBeforeMount, ref } from 'vue'
import TagsRelationAddDialog from './TagsRelationAddDialog.vue'
import TagForm from '@/views/Tag/components/Form.vue'
import { useTagListState } from '@/models/Tag/States'
import MedicationsApi from '@/models/Medication/Api'
import type { Medication } from '@/models/Medication/Model'
import type { Tag } from '@/models/Tag/Model'

const props = defineProps<{
	medicationId: Medication['id']
}>()

const emit = defineEmits<{
	(e: 'start-loading'): void
	(e: 'stop-loading'): void
}>()

const listState = useTagListState()
listState.defaultParams = {
	per_page: 10,
	fromRelation: {
		model: 'App\\Models\\Medication',
		id: props.medicationId,
		relation: 'tags',
	},
}
const { ApiTable, Column, ApiTableLinkButton } = useApiTable(listState)

const isRelationAddDialogActive = ref(false)
const isFormActive = ref(false)
const detachLoading = ref(null as null | number | string)

onBeforeMount(() => {
	refresh()
})

async function refresh() {
	emit('start-loading')
	try {
		await listState.getList()
	} finally {
		emit('stop-loading')
	}
}

async function detach(item: Tag) {
	detachLoading.value = item.id
	emit('start-loading')
	try {
		await new MedicationsApi().updateRelation(props.medicationId, 'tags', {
			method: 'detach',
			params: [item.id],
		})
		detachLoading.value = null
		await refresh()
	} finally {
		detachLoading.value = null
		emit('stop-loading')
	}
}
</script>

<style lang="scss" scoped>
.tags-relation-widget {
	width: 100%;
	max-width: 600px;
	overflow: hidden;

	:deep(.p-card-body) {
		padding: 20px 0 0;

		.p-card-caption {
			padding: 0px 20px 12px;

			.p-card-title {
				display: flex;
				align-items: center;
				gap: 10px;

				.tags-relation-widget__title {
					flex: 1;
					text-align: left;
				}
			}
		}
	}

	.tags-relation-widget__table-button {
		width: 30px;
		height: 30px;
	}
}
</style>
