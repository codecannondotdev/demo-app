<template>
    <svg width="14" height="14" viewBox="0 0 448 512" fill="none" xmlns="http://www.w3.org/2000/svg" v-bind="pti()">
		<path d="M441.4 67.1c7.1 5.2 8.7 15.2 3.5 22.4l-280 384c-2.8 3.8-7 6.2-11.7 6.5s-9.2-1.3-12.6-4.6l-136-136c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l122.8 122.8 269-368.9c5.2-7.1 15.2-8.7 22.4-3.5z" fill="currentColor" />
	</svg>
</template>
<script>
import BaseIcon from '@primevue/icons/baseicon';

export default {
    name: 'CheckIcon',
    extends: BaseIcon
};
</script>
