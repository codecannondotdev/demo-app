<template>
    <svg width="14" height="14" viewBox="0 0 576 512" fill="none" xmlns="http://www.w3.org/2000/svg" v-bind="pti()">
		<path d="M27.3-27.2c-6.2-6.2-16.4-6.2-22.6 0s-6.2 16.4 0 22.6l544 544c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6L353.9 299.4 534.6 118.6c9.2-9.2 11.9-22.9 6.9-34.9S524.9 64 512 64L118.5 64 27.3-27.2zM150.5 96L512 96 331.3 276.7 150.5 96zM224 301.3l0 0 0 114.7c0 8.5 3.4 16.6 9.4 22.6l64 64c9.2 9.2 22.9 11.9 34.9 6.9S352 492.9 352 480l0-69.5-32-32 0 101.5-64-64 0-101.5-32-32 0 18.7z" fill="currentColor" />
	</svg>
</template>

<script>
import BaseIcon from '@primevue/icons/baseicon';

export default {
    name: 'FilterSlashIcon',
    extends: BaseIcon
};
</script>
