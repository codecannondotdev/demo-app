<template>
    <svg width="14" height="14" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg" v-bind="pti()">
		<path d="M256 32a16 16 0 1 1 0 32 16 16 0 1 1 0-32zm0 64a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm0 352a16 16 0 1 1 0 32 16 16 0 1 1 0-32zm0 64a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM32 256a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zm64 0a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm368-16a16 16 0 1 1 0 32 16 16 0 1 1 0-32zm0 64a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM97.6 414.4a16 16 0 1 1 22.6-22.6 16 16 0 1 1 -22.6 22.6zm45.3-45.3A48 48 0 1 0 75 437 48 48 0 1 0 142.9 369.1zM120.2 97.6a16 16 0 1 1 -22.6 22.6 16 16 0 1 1 22.6-22.6zM75 142.9A48 48 0 1 0 142.9 75 48 48 0 1 0 75 142.9zM391.8 391.8a16 16 0 1 1 22.6 22.6 16 16 0 1 1 -22.6-22.6zM437 437A48 48 0 1 0 369.1 369.1 48 48 0 1 0 437 437z" fill="currentColor" />
	</svg>
</template>

<script>
import BaseIcon from '@primevue/icons/baseicon';

export default {
    name: 'SpinnerIcon',
    extends: BaseIcon
};
</script>
