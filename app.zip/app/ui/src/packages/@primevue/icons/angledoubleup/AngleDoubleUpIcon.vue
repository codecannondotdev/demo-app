<template>
    <svg width="14" height="14" viewBox="0 0 384 512" fill="none" xmlns="http://www.w3.org/2000/svg" v-bind="pti()">
		<path d="M203.3 52.7c-6.2-6.2-16.4-6.2-22.6 0l-160 160c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L192 86.6 340.7 235.3c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6l-160-160zm160 352l-160-160c-6.2-6.2-16.4-6.2-22.6 0l-160 160c-6.2 6.2-6.2 16.4 0 22.6s16.4 6.2 22.6 0L192 278.6 340.7 427.3c6.2 6.2 16.4 6.2 22.6 0s6.2-16.4 0-22.6z" fill="currentColor" />
	</svg>
</template>
<script>
import BaseIcon from '@primevue/icons/baseicon';

export default {
    name: 'AngleDoubleUpIcon',
    extends: BaseIcon
};
</script>
