<template>
	<svg
		width="14"
		height="14"
		viewBox="0 0 512 512"
		xmlns="http://www.w3.org/2000/svg"
		v-bind="pti()">
		<path
			fill="currentColor"
			d="M32 64C19.1 64 7.4 71.8 2.4 83.8S.2 109.5 9.4 118.6L192 301.3 192 416c0 8.5 3.4 16.6 9.4 22.6l64 64c9.2 9.2 22.9 11.9 34.9 6.9S320 492.9 320 480l0-178.7 182.6-182.6c9.2-9.2 11.9-22.9 6.9-34.9S492.9 64 480 64L32 64z" />
	</svg>
</template>

<script>
import BaseIcon from '@primevue/icons/baseicon'

export default {
	name: 'FilterFillIcon',
	extends: BaseIcon,
}
</script>
