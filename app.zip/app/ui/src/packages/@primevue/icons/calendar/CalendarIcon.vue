<template>
    <svg width="14" height="14" viewBox="0 0 448 512" fill="none" xmlns="http://www.w3.org/2000/svg" v-bind="pti()">
		<path d="M112 0c8.8 0 16 7.2 16 16l0 48 192 0 0-48c0-8.8 7.2-16 16-16s16 7.2 16 16l0 48 32 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l32 0 0-48c0-8.8 7.2-16 16-16zM384 96L64 96c-17.7 0-32 14.3-32 32l0 32 384 0 0-32c0-17.7-14.3-32-32-32zm32 96l-384 0 0 224c0 17.7 14.3 32 32 32l320 0c17.7 0 32-14.3 32-32l0-224z" fill="currentColor" />
	</svg>
</template>
<script>
import BaseIcon from '@primevue/icons/baseicon';

export default {
    name: 'CalendarIcon',
    extends: BaseIcon
};
</script>
