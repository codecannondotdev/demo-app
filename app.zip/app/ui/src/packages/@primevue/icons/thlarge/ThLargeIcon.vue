<template>
    <svg width="14" height="14" viewBox="0 0 448 512" fill="none" xmlns="http://www.w3.org/2000/svg" v-bind="pti()">
		<path d="M240 64l0 176 176 0 0-144c0-17.7-14.3-32-32-32L240 64zm-32 0L64 64C46.3 64 32 78.3 32 96l0 144 176 0 0-176zM0 272L0 96C0 60.7 28.7 32 64 32l320 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 272zm416 0l-176 0 0 176 144 0c17.7 0 32-14.3 32-32l0-144zM208 448l0-176-176 0 0 144c0 17.7 14.3 32 32 32l144 0z" fill="currentColor" />
	</svg>
</template>

<script>
import BaseIcon from '@primevue/icons/baseicon';

export default {
    name: 'ThLargeIcon',
    extends: BaseIcon
};
</script>
